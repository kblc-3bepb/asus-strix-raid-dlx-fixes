﻿#Requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Check','Install','Restore','Restart')]
    [string]$Mode='Check',
    [switch]$PauseAtEnd
)
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
$packageRoot=Split-Path -Parent $PSScriptRoot
$exitCode=0
$transcribing=$false
try {
    if ($env:OS -ne 'Windows_NT') { throw 'Сценарий предназначен для Windows 10/11 x64.' }
    if (-not [Environment]::Is64BitOperatingSystem -or -not [Environment]::Is64BitProcess) {
        throw 'Нужен 64-разрядный Windows PowerShell. Запускайте файлы .cmd из корня распакованного архива.'
    }
    if ($env:PROCESSOR_ARCHITECTURE -ine 'AMD64') { throw 'Автоматическая установка поддерживает архитектуру x64 (AMD64). Для другой архитектуры используйте ручную инструкцию.' }
    $os=Get-CimInstance Win32_OperatingSystem
    if ([int]$os.BuildNumber -lt 19041) { throw 'Автоматический сценарий рассчитан на Windows 10 2004 и новее. Для старых систем используйте ручную инструкцию.' }
    if ($Mode -ne 'Check') {
        $principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
        if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
            $shell=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
            $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $PSCommandPath),'-Mode',$Mode,'-PauseAtEnd')
            $child=Start-Process -FilePath $shell -ArgumentList $arguments -Verb RunAs -Wait -PassThru
            $PauseAtEnd=$false
            exit $child.ExitCode
        }
    }
    try {
        $logs=Join-Path $packageRoot 'Logs'
        $null=New-Item -Path $logs -ItemType Directory -Force
        $logPath=Join-Path $logs ((Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+$Mode+'_'+([Guid]::NewGuid().ToString('N').Substring(0,6))+'.txt')
        $null=Start-Transcript -Path $logPath -Force
        $transcribing=$true
    } catch { Write-Host ('Журнал записать не удалось: '+$_.Exception.Message) -ForegroundColor Yellow }
    Write-Host 'ASUS STRIX RAID DLX — Microsoft USB xHCI / 1.0.0' -ForegroundColor Cyan
    Write-Host ('Режим: '+$Mode)
    . (Join-Path $PSScriptRoot 'DriverCore.ps1')
    switch ($Mode) {
        'Check' { Show-Diagnostics }
        'Install' {
            $result=Invoke-InstallMicrosoft $packageRoot
            if ($result.RebootRequired) { $exitCode=3010 }
            try { Show-Diagnostics } catch { Write-Host ('Диагностика после установки: '+$_.Exception.Message) -ForegroundColor Yellow }
        }
        'Restore' {
            $result=Invoke-RestoreDriver $packageRoot
            if ($result.RebootRequired) { $exitCode=3010 }
            try { Show-Diagnostics } catch { Write-Host ('Диагностика после возврата: '+$_.Exception.Message) -ForegroundColor Yellow }
        }
        'Restart' {
            $result=Invoke-RestartController
            if ($result.RebootRequired) { $exitCode=3010 }
            Start-Sleep -Seconds 5
            try { Show-Diagnostics } catch { Write-Host ('Диагностика после перезапуска: '+$_.Exception.Message) -ForegroundColor Yellow }
        }
    }
} catch {
    Write-Host ("`nОШИБКА: "+$_.Exception.Message) -ForegroundColor Red
    Write-Host 'Подробности: INSTRUCTION_RU.html; ручной способ — через список совместимых драйверов в диспетчере устройств.'
    $exitCode=1
} finally {
    if ($transcribing) {
        Write-Host ("`nЖурнал: "+$logPath)
        $null=Stop-Transcript
    }
    if ($PauseAtEnd) { $null=Read-Host 'Нажмите Enter для закрытия окна' }
}
exit $exitCode
