﻿# Windows PowerShell 5.1-compatible functions. No automatic action on import.
$script:TargetRegex = '^PCI\\VEN_1B21&DEV_1142&SUBSYS_86A01043(?:&|\\|$)'

function Get-StrixController {
    $found = @(Get-PnpDevice -PresentOnly -ErrorAction Stop | Where-Object { $_.InstanceId -match $script:TargetRegex })
    if ($found.Count -eq 0) { throw 'Контроллер ASUS STRIX RAID DLX не обнаружен. Проверьте установку карты и используйте ручную инструкцию.' }
    if ($found.Count -ne 1) { throw 'Найдено несколько одинаковых контроллеров STRIX. Автоматическое изменение остановлено; используйте ручной выбор.' }
    return $found[0]
}

function Get-DeviceValue {
    param([string]$InstanceId, [string]$Key)
    return (Get-PnpDeviceProperty -InstanceId $InstanceId -KeyName $Key -ErrorAction Stop).Data
}

function Get-ControllerDriver {
    param([string]$InstanceId)
    return [pscustomobject]@{
        DeviceID = $InstanceId
        Provider = [string](Get-DeviceValue $InstanceId 'DEVPKEY_Device_DriverProvider')
        Version = [string](Get-DeviceValue $InstanceId 'DEVPKEY_Device_DriverVersion')
        InfName = [string](Get-DeviceValue $InstanceId 'DEVPKEY_Device_DriverInfPath')
        Service = [string](Get-DeviceValue $InstanceId 'DEVPKEY_Device_Service')
    }
}

function Test-MicrosoftXhci {
    param($Driver)
    return (($Driver.InfName -ieq 'usbxhci.inf') -and ($Driver.Service -ieq 'USBXHCI') -and
        ($Driver.Provider -match 'Microsoft|Майкрософт'))
}

function Assert-XhciCompatibility {
    param($Controller)
    $ids = @(Get-DeviceValue $Controller.InstanceId 'DEVPKEY_Device_CompatibleIds')
    if (@($ids | Where-Object { $_ -match '^PCI\\CC_0C0330' }).Count -eq 0) {
        throw 'Совместимый идентификатор PCI xHCI не подтверждён. Автоматическая установка остановлена.'
    }
}

function Import-NativeDriver {
    param([string]$PackageRoot)
    if (-not ('StrixColdStart.NativeDriver' -as [type])) {
        Add-Type -Path (Join-Path $PackageRoot 'scripts\NativeDriver.cs') -ErrorAction Stop
    }
}

function Invoke-PnpExport {
    param([string]$InfName, [string]$Destination)
    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $lines = @(& "$env:SystemRoot\System32\pnputil.exe" /export-driver $InfName $Destination 2>&1)
        $resultCode = $LASTEXITCODE
    } finally { $ErrorActionPreference = $savedPreference }
    foreach ($line in $lines) { Write-Host ([string]$line) }
    if ($resultCode -ne 0) { throw "Не удалось сохранить пакет $InfName; код $resultCode. Драйвер не изменён." }
}

function Write-StateJson {
    param($State, [string]$Path)
    $State | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $Path -Encoding UTF8 -ErrorAction Stop
}

function New-DriverBackup {
    param($Controller, $Driver, [string]$PackageRoot)
    if ($Driver.InfName -notmatch '^oem\d+\.inf$') {
        throw 'Текущий сторонний пакет не имеет имени oemN.inf. Автоматическая резервная копия невозможна; используйте ручной способ.'
    }
    $folderName = (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + ([Guid]::NewGuid().ToString('N').Substring(0,8))
    $backup = Join-Path (Join-Path $PackageRoot 'Backups') $folderName
    $null = New-Item -Path $backup -ItemType Directory -Force -ErrorAction Stop
    $packageList = New-Object System.Collections.ArrayList
    $null = $packageList.Add([pscustomobject]@{ Role='Controller'; InfName=$Driver.InfName })
    foreach ($node in @(Get-PnpDevice -PresentOnly -Class USB -ErrorAction Stop)) {
        if ($node.InstanceId -eq $Controller.InstanceId) { continue }
        try {
            $parent = Get-DeviceValue $node.InstanceId 'DEVPKEY_Device_Parent'
            if ($parent -ine $Controller.InstanceId) { continue }
            $inf = [string](Get-DeviceValue $node.InstanceId 'DEVPKEY_Device_DriverInfPath')
            if ($inf -match '^oem\d+\.inf$' -and @($packageList | Where-Object { $_.InfName -ieq $inf }).Count -eq 0) {
                $null = $packageList.Add([pscustomobject]@{ Role='RootHub'; InfName=$inf })
            }
        } catch { Write-Host ('Сведения дочернего узла недоступны: ' + $_.Exception.Message) }
    }
    $exports = @()
    foreach ($entry in $packageList) {
        $destination = Join-Path $backup ('Drivers\' + $entry.InfName)
        $null = New-Item -Path $destination -ItemType Directory -Force -ErrorAction Stop
        Invoke-PnpExport $entry.InfName $destination
        $infs = @(Get-ChildItem -LiteralPath $destination -Recurse -File -Filter '*.inf')
        if ($infs.Count -ne 1) { throw "Экспорт $($entry.InfName) не дал один однозначный INF. Изменение драйвера остановлено." }
        $relative = $infs[0].FullName.Substring($backup.Length + 1)
        $exports += [pscustomobject]@{ Role=$entry.Role; PublishedInf=$entry.InfName; InfRelativePath=$relative }
    }
    $hashes = @()
    foreach ($file in @(Get-ChildItem -LiteralPath (Join-Path $backup 'Drivers') -Recurse -File)) {
        $hashes += [pscustomobject]@{ Path=$file.FullName.Substring($backup.Length+1); SHA256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash }
    }
    $state = [pscustomobject]@{
        SchemaVersion=1
        ToolVersion='1.0.0'
        CreatedAt=(Get-Date).ToString('o')
        ComputerName=$env:COMPUTERNAME
        InstanceId=$Controller.InstanceId
        HardwareIds=@(Get-DeviceValue $Controller.InstanceId 'DEVPKEY_Device_HardwareIds')
        DriverBefore=$Driver
        Exports=$exports
        Files=$hashes
    }
    Write-StateJson $state (Join-Path $backup 'before.json')
    Write-Host "Резервная копия: $backup"
    return $backup
}

function Wait-ForDriver {
    param([string]$InstanceId, [string]$Provider, [string]$Version, [switch]$MicrosoftXhci)
    $driver = $null
    for ($attempt=0; $attempt -lt 10; $attempt++) {
        try {
            $driver = Get-ControllerDriver $InstanceId
            if ($MicrosoftXhci) {
                if (Test-MicrosoftXhci $driver) { return $driver }
            } elseif ($driver.Provider -ieq $Provider -and $driver.Version -eq $Version) { return $driver }
        } catch { }
        Start-Sleep -Seconds 2
    }
    return $driver
}

function Invoke-InstallMicrosoft {
    param([string]$PackageRoot)
    $controller = Get-StrixController
    Assert-XhciCompatibility $controller
    $before = Get-ControllerDriver $controller.InstanceId
    if (Test-MicrosoftXhci $before) {
        Write-Host 'Microsoft USB xHCI уже выбран. Повторная установка не нужна.' -ForegroundColor Green
        return [pscustomobject]@{ Changed=$false; RebootRequired=$false }
    }
    $inf = Join-Path $env:SystemRoot 'INF\usbxhci.inf'
    if (-not (Test-Path -LiteralPath $inf -PathType Leaf)) { throw 'Встроенный usbxhci.inf не найден. Используйте ручную инструкцию; файлы Windows не заменялись.' }
    Import-NativeDriver $PackageRoot
    $candidate = [StrixColdStart.NativeDriver]::Select($controller.InstanceId,$inf,$true,$false)
    Write-Host ('Совместимый драйвер: {0}; {1}; {2}' -f $candidate.Description,$candidate.Provider,$candidate.Version)
    $backup = New-DriverBackup $controller $before $PackageRoot
    $installed = [StrixColdStart.NativeDriver]::Select($controller.InstanceId,$inf,$true,$true)
    $after = Wait-ForDriver -InstanceId $controller.InstanceId -MicrosoftXhci
    Write-StateJson ([pscustomobject]@{ Action='InstallMicrosoft'; RebootRequired=$installed.RebootRequired; DriverAfter=$after }) (Join-Path $backup 'result.json')
    if ($installed.RebootRequired) {
        Write-Host 'Windows просит перезагрузку для завершения установки. Сохраните работу и перезагрузите ПК самостоятельно.' -ForegroundColor Yellow
    } elseif (-not ($null -ne $after -and (Test-MicrosoftXhci $after))) {
        throw "API установки завершился, но итоговый драйвер не подтверждён. Проверьте диспетчер устройств; резервная копия: $backup"
    } else { Write-Host 'Установлен и подтверждён встроенный Microsoft USB xHCI.' -ForegroundColor Green }
    return [pscustomobject]@{ Changed=$true; RebootRequired=$installed.RebootRequired }
}

function Resolve-BackupFile {
    param([string]$BackupRoot, [string]$RelativePath)
    if ([IO.Path]::IsPathRooted($RelativePath)) { throw 'В резервной копии указан абсолютный путь.' }
    $prefix = [IO.Path]::GetFullPath($BackupRoot).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $full = [IO.Path]::GetFullPath((Join-Path $BackupRoot $RelativePath))
    if (-not $full.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { throw 'Путь резервной копии выходит за пределы её папки.' }
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "Файл резервной копии отсутствует: $full" }
    return $full
}

function Find-LatestBackup {
    param($Controller, [string]$PackageRoot)
    $root = Join-Path $PackageRoot 'Backups'
    if (Test-Path -LiteralPath $root) {
        $hardware = @(Get-DeviceValue $Controller.InstanceId 'DEVPKEY_Device_HardwareIds')
        foreach ($dir in @(Get-ChildItem -LiteralPath $root -Directory | Sort-Object Name -Descending)) {
            $json = Join-Path $dir.FullName 'before.json'
            if (-not (Test-Path -LiteralPath $json)) { continue }
            try {
                $state = Get-Content -LiteralPath $json -Raw -Encoding UTF8 | ConvertFrom-Json
                if ($state.SchemaVersion -ne 1 -or $state.ComputerName -ine $env:COMPUTERNAME) { continue }
                if (@($state.HardwareIds | Where-Object { $_ -in $hardware }).Count -eq 0) { continue }
                if (@($state.Exports | Where-Object { $_.Role -eq 'Controller' }).Count -ne 1) { continue }
                return [pscustomobject]@{ Directory=$dir.FullName; State=$state }
            } catch { Write-Host ('Пропущена неполная резервная копия: ' + $dir.Name) }
        }
    }
    throw 'Подходящей резервной копии для этого ПК нет. Если Microsoft уже был установлен до распаковки архива, это нормально. Вернуть ASMedia можно вручную через список драйверов.'
}

function Invoke-RestoreDriver {
    param([string]$PackageRoot)
    $controller = Get-StrixController
    Assert-XhciCompatibility $controller
    $backup = Find-LatestBackup $controller $PackageRoot
    Write-Host ('Возврат к драйверу из: ' + $backup.Directory)
    foreach ($item in $backup.State.Files) {
        $file = Resolve-BackupFile $backup.Directory $item.Path
        if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ine $item.SHA256) { throw "Контрольная сумма резервной копии не совпала: $file" }
    }
    Import-NativeDriver $PackageRoot
    $controllerInf = $null
    foreach ($item in $backup.State.Exports) {
        $inf = Resolve-BackupFile $backup.Directory $item.InfRelativePath
        $staged = [StrixColdStart.NativeDriver]::Stage($inf)
        if ($item.Role -eq 'Controller') { $controllerInf=$staged }
    }
    if ([string]::IsNullOrWhiteSpace($controllerInf)) { throw 'Не найден пакет контроллера для возврата.' }
    $installed = [StrixColdStart.NativeDriver]::Select($controller.InstanceId,$controllerInf,$false,$true)
    $old = $backup.State.DriverBefore
    $after = Wait-ForDriver -InstanceId $controller.InstanceId -Provider $old.Provider -Version $old.Version
    if ($installed.RebootRequired) {
        Write-Host 'Для завершения возврата Windows просит перезагрузку. Сохраните работу и перезагрузите ПК самостоятельно.' -ForegroundColor Yellow
    } elseif ($null -eq $after -or $after.Provider -ine $old.Provider -or $after.Version -ne $old.Version) {
        throw 'Возврат вызван, но поставщик и версия ещё не подтверждены. Проверьте диспетчер устройств и при необходимости перезагрузите ПК.'
    } else { Write-Host ('Возвращён драйвер: {0} {1}' -f $after.Provider,$after.Version) -ForegroundColor Green }
    return [pscustomobject]@{ Changed=$true; RebootRequired=$installed.RebootRequired }
}

function Invoke-RestartController {
    $controller = Get-StrixController
    Write-Host ('Перезапуск только контроллера STRIX: ' + $controller.InstanceId)
    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        $lines = @(& "$env:SystemRoot\System32\pnputil.exe" /restart-device $controller.InstanceId 2>&1)
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference=$savedPreference }
    foreach ($line in $lines) { Write-Host ([string]$line) }
    if ($code -eq 3010) {
        Write-Host 'Windows запросила перезагрузку. Скрипт не перезагружает ПК автоматически.' -ForegroundColor Yellow
    } elseif ($code -ne 0) { throw "Перезапуск устройства: код $code. Проверьте сообщение Windows выше." }
    return [pscustomobject]@{ Changed=$true; RebootRequired=($code -eq 3010) }
}

function Show-Diagnostics {
    Write-Host "`n=== Windows ==="
    Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,OSArchitecture | Format-List | Out-Host
    Write-Host '=== Контроллер STRIX ==='
    $controller=Get-StrixController
    $controller | Select-Object Status,Class,FriendlyName,InstanceId | Format-List | Out-Host
    $driver=Get-ControllerDriver $controller.InstanceId
    $driver | Format-List | Out-Host
    if (Test-MicrosoftXhci $driver) { Write-Host 'РЕЗУЛЬТАТ: выбран встроенный Microsoft USB xHCI.' -ForegroundColor Green }
    else { Write-Host 'РЕЗУЛЬТАТ: выбран другой драйвер. Сверьте ручную инструкцию.' -ForegroundColor Yellow }
    Write-Host "`n=== USB-устройства ASUS STRIX ==="
    $audio=@(Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -like 'USB\VID_0B05&PID_180C*' })
    if ($audio.Count -eq 0) { Write-Host 'USB-аудиочасть VID_0B05&PID_180C сейчас не обнаружена.' -ForegroundColor Yellow }
    else { $audio | Select-Object Status,Class,FriendlyName,InstanceId | Format-List | Out-Host }
    Write-Host '=== Аудиовыходы STRIX ==='
    Get-PnpDevice -PresentOnly -Class AudioEndpoint | Where-Object { $_.FriendlyName -match 'STRIX' } |
        Select-Object Status,FriendlyName | Format-Table -AutoSize | Out-Host
    Write-Host '=== Быстрый запуск: 0 = выключен, 1 = разрешён в настройках ==='
    try { Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name HiberbootEnabled | Select-Object HiberbootEnabled | Format-List | Out-Host }
    catch { Write-Host 'Значение HiberbootEnabled прочитать не удалось.' }
    Write-Host '=== Последние загрузки: 0x0 = полный запуск, 0x1 = быстрый запуск ==='
    try { Get-WinEvent -FilterHashtable @{ LogName='System'; ProviderName='Microsoft-Windows-Kernel-Boot'; Id=27 } -MaxEvents 3 | Format-List TimeCreated,Message | Out-Host }
    catch { Write-Host 'События загрузки недоступны; это не мешает выбору драйвера.' }
}
