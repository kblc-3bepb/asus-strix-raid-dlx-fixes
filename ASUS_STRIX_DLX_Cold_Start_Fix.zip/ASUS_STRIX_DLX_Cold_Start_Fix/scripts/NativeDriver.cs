﻿// Source included for inspection. Windows x64 only; no downloads or external tools.
using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

namespace StrixColdStart
{
    public sealed class DriverResult
    {
        public string Description;
        public string Provider;
        public string Version;
        public uint Rank;
        public bool Installed;
        public bool RebootRequired;
    }

    public static class NativeDriver
    {
        private const uint COMPAT = 2;
        private const uint ENUM_SINGLE_INF = 0x00010000;
        private const uint ALLOW_EXCLUDED = 0x00000800;
        private const int NO_MORE_ITEMS = 259;

        [StructLayout(LayoutKind.Sequential)]
        private struct DeviceData
        {
            public uint cbSize;
            public Guid ClassGuid;
            public uint DevInst;
            public UIntPtr Reserved;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct InstallParams
        {
            public uint cbSize;
            public uint Flags;
            public uint FlagsEx;
            public IntPtr hwndParent;
            public IntPtr InstallMsgHandler;
            public IntPtr InstallMsgHandlerContext;
            public IntPtr FileQueue;
            public UIntPtr ClassInstallReserved;
            public uint Reserved;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            public string DriverPath;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct DriverData
        {
            public uint cbSize;
            public uint DriverType;
            public UIntPtr Reserved;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
            public string Description;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
            public string MfgName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
            public string ProviderName;
            public System.Runtime.InteropServices.ComTypes.FILETIME DriverDate;
            public ulong DriverVersion;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DriverInstallParams
        {
            public uint cbSize;
            public uint Rank;
            public uint Flags;
            public UIntPtr PrivateData;
            public uint Reserved;
        }

        [DllImport("setupapi.dll", ExactSpelling = true, SetLastError = true)]
        private static extern IntPtr SetupDiCreateDeviceInfoList(IntPtr guid, IntPtr hwnd);
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetupDiOpenDeviceInfoW(IntPtr set, string id, IntPtr hwnd, uint flags, ref DeviceData data);
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetupDiGetDeviceInstallParamsW(IntPtr set, ref DeviceData data, ref InstallParams parameters);
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetupDiSetDeviceInstallParamsW(IntPtr set, ref DeviceData data, ref InstallParams parameters);
        [DllImport("setupapi.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetupDiBuildDriverInfoList(IntPtr set, ref DeviceData data, uint type);
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetupDiEnumDriverInfoW(IntPtr set, ref DeviceData data, uint type, uint index, ref DriverData driver);
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetupDiGetDriverInstallParamsW(IntPtr set, ref DeviceData data, ref DriverData driver, ref DriverInstallParams parameters);
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetupDiSetSelectedDriverW(IntPtr set, ref DeviceData data, ref DriverData driver);
        [DllImport("setupapi.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetupDiDestroyDriverInfoList(IntPtr set, ref DeviceData data, uint type);
        [DllImport("setupapi.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetupDiDestroyDeviceInfoList(IntPtr set);
        [DllImport("newdev.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool DiInstallDevice(IntPtr hwnd, IntPtr set, ref DeviceData data,
            ref DriverData driver, uint flags, [MarshalAs(UnmanagedType.Bool)] out bool reboot);
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetupCopyOEMInfW(string source, string media, uint mediaType,
            uint style, StringBuilder destination, uint size, out uint required, IntPtr component);

        public static bool IsTarget(string instanceId)
        {
            return instanceId != null && Regex.IsMatch(instanceId,
                @"^PCI\\VEN_1B21&DEV_1142&SUBSYS_86A01043(?:&|\\|$)", RegexOptions.IgnoreCase);
        }

        public static int[] LayoutSizes()
        {
            return new int[] { Marshal.SizeOf(typeof(DeviceData)), Marshal.SizeOf(typeof(InstallParams)),
                Marshal.SizeOf(typeof(DriverData)), Marshal.SizeOf(typeof(DriverInstallParams)) };
        }

        private static void Check(bool ok, string operation)
        {
            if (!ok) throw new Win32Exception(Marshal.GetLastWin32Error(), operation);
        }

        private static string VersionText(ulong version)
        {
            return String.Format("{0}.{1}.{2}.{3}", (version >> 48) & 65535,
                (version >> 32) & 65535, (version >> 16) & 65535, version & 65535);
        }

        // Only compatible candidates from exactly one INF are considered.
        // Supplying DriverData to DiInstallDevice explicitly selects that driver,
        // instead of allowing PnPUtil ranking to retain the ASMedia package.
        public static DriverResult Select(string instanceId, string infPath, bool requireMicrosoft, bool install)
        {
            if (!Environment.Is64BitProcess) throw new InvalidOperationException("Use native x64 PowerShell.");
            if (!IsTarget(instanceId)) throw new InvalidOperationException("Device is not the supported ASUS STRIX controller.");
            infPath = Path.GetFullPath(infPath);
            if (!File.Exists(infPath) || !String.Equals(Path.GetExtension(infPath), ".inf", StringComparison.OrdinalIgnoreCase))
                throw new FileNotFoundException("INF not found.", infPath);
            if (infPath.Length >= 260) throw new InvalidOperationException("INF path is too long.");
            if (requireMicrosoft && !String.Equals(Path.GetFileName(infPath), "usbxhci.inf", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Expected the Windows inbox usbxhci.inf.");

            IntPtr set = SetupDiCreateDeviceInfoList(IntPtr.Zero, IntPtr.Zero);
            if (set == new IntPtr(-1)) throw new Win32Exception(Marshal.GetLastWin32Error());
            DeviceData device = new DeviceData();
            device.cbSize = (uint)Marshal.SizeOf(typeof(DeviceData));
            bool listBuilt = false;
            try
            {
                Check(SetupDiOpenDeviceInfoW(set, instanceId, IntPtr.Zero, 0, ref device), "SetupDiOpenDeviceInfo");
                InstallParams parameters = new InstallParams();
                parameters.cbSize = (uint)Marshal.SizeOf(typeof(InstallParams));
                Check(SetupDiGetDeviceInstallParamsW(set, ref device, ref parameters), "SetupDiGetDeviceInstallParams");
                parameters.Flags |= ENUM_SINGLE_INF;
                parameters.FlagsEx |= ALLOW_EXCLUDED;
                parameters.DriverPath = infPath;
                Check(SetupDiSetDeviceInstallParamsW(set, ref device, ref parameters), "SetupDiSetDeviceInstallParams");
                Check(SetupDiBuildDriverInfoList(set, ref device, COMPAT), "SetupDiBuildDriverInfoList");
                listBuilt = true;
                bool found = false;
                DriverData best = new DriverData();
                uint bestRank = UInt32.MaxValue;
                for (uint index = 0; ; index++)
                {
                    DriverData driver = new DriverData();
                    driver.cbSize = (uint)Marshal.SizeOf(typeof(DriverData));
                    if (!SetupDiEnumDriverInfoW(set, ref device, COMPAT, index, ref driver))
                    {
                        int error = Marshal.GetLastWin32Error();
                        if (error == NO_MORE_ITEMS) break;
                        throw new Win32Exception(error, "SetupDiEnumDriverInfo");
                    }
                    if (requireMicrosoft && (driver.ProviderName == null ||
                        (driver.ProviderName.IndexOf("Microsoft", StringComparison.OrdinalIgnoreCase) < 0 &&
                         driver.ProviderName.IndexOf("Майкрософт", StringComparison.OrdinalIgnoreCase) < 0))) continue;
                    DriverInstallParams ranking = new DriverInstallParams();
                    ranking.cbSize = (uint)Marshal.SizeOf(typeof(DriverInstallParams));
                    Check(SetupDiGetDriverInstallParamsW(set, ref device, ref driver, ref ranking), "SetupDiGetDriverInstallParams");
                    if (!found || ranking.Rank < bestRank ||
                        (ranking.Rank == bestRank && driver.DriverVersion > best.DriverVersion))
                    {
                        best = driver;
                        bestRank = ranking.Rank;
                        found = true;
                    }
                }
                if (!found) throw new InvalidOperationException("No compatible driver in this INF. Use the manual guide.");
                DriverResult result = new DriverResult();
                result.Description = best.Description;
                result.Provider = best.ProviderName;
                result.Version = VersionText(best.DriverVersion);
                result.Rank = bestRank;
                if (install)
                {
                    Check(SetupDiSetSelectedDriverW(set, ref device, ref best), "SetupDiSetSelectedDriver");
                    bool reboot;
                    Check(DiInstallDevice(IntPtr.Zero, set, ref device, ref best, 0, out reboot), "DiInstallDevice");
                    result.Installed = true;
                    result.RebootRequired = reboot;
                }
                return result;
            }
            finally
            {
                if (listBuilt) SetupDiDestroyDriverInfoList(set, ref device, COMPAT);
                SetupDiDestroyDeviceInfoList(set);
            }
        }

        // Stage a backed-up OEM package; this does not rebind other devices.
        public static string Stage(string infPath)
        {
            if (!File.Exists(infPath)) throw new FileNotFoundException("Backup INF not found.", infPath);
            StringBuilder destination = new StringBuilder(1024);
            uint required;
            Check(SetupCopyOEMInfW(Path.GetFullPath(infPath), null, 1, 0,
                destination, (uint)destination.Capacity, out required, IntPtr.Zero), "SetupCopyOEMInf");
            return destination.ToString();
        }
    }
}
