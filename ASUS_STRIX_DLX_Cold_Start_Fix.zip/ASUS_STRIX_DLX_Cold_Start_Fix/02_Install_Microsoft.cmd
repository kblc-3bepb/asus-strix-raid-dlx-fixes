@echo off
setlocal
set "STRIX_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "STRIX_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%STRIX_PS%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\StrixDriver.ps1" -Mode Install -PauseAtEnd
set "STRIX_RESULT=%ERRORLEVEL%"
if "%STRIX_RESULT%"=="3010" echo Windows requested a restart. Save your work and restart manually.
endlocal & exit /b %STRIX_RESULT%
