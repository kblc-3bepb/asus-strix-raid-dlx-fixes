@echo off
chcp 65001 >nul
setlocal
title PotPlayer + ASUS STRIX RAID DLX - Stereo Fix
set "Tool=%~dp0SoundVolumeView\SoundVolumeView.exe"
if not exist "%Tool%" (
    echo Не найден файл SoundVolumeView\SoundVolumeView.exe.
    echo Распакуй архив целиком и сохрани расположение папок.
    echo.
    pause
    exit /b 1
)
echo Восстановление баланса PotPlayer на ASUS STRIX RAID DLX.
echo Для применения PotPlayer должен воспроизводить звук через ASUS.
echo.
"%Tool%" /SetVolumeChannels "*STRIX RAID DLX\Application\PotPlayer" 100 100
echo.
echo Команда отправлена: левый и правый каналы PotPlayer на ASUS — по 100%%.
echo Проверь звук с выключенным системным моно.
echo В свойствах сеанса Channels Percent должно быть 100.0%%, 100.0%%.
echo Если результата нет, открой START_HERE_RU.txt.
echo.
pause
endlocal
