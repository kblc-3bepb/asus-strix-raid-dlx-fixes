@echo off
setlocal
title ASUS STRIX - Install clean autostart
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0StrixControlFix.ps1" -Mode Install
set "strix_exit=%errorlevel%"
echo.
pause
exit /b %strix_exit%
