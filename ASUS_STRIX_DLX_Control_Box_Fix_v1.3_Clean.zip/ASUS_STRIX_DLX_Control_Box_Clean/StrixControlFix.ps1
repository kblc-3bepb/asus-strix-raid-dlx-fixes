﻿#Requires -Version 5.1
# Clean edition of the validated 1.3 startup recovery. No diagnostic files.
[CmdletBinding()]
param(
    [ValidateSet('Install', 'Worker', 'Uninstall')]
    [string]$Mode = 'Install'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:Base = Join-Path $env:LOCALAPPDATA 'ASUS_StrixControlFix'
$script:Installed = Join-Path $script:Base 'StrixControlFix.ps1'
$script:Enabled = Join-Path $script:Base 'enabled.flag'
$script:Identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$script:Sid = $script:Identity.User.Value
$script:Session = [Diagnostics.Process]::GetCurrentProcess().SessionId
$script:TaskName = 'ASUS_StrixControl_Recovery_' + $script:Sid
# Keep the ownership token/path compatible with the diagnostic 1.3 installer.
$script:Marker = 'Managed by StrixControlFix.ps1 v1.3'
$script:PowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$script:DriverDir = Join-Path $env:ProgramFiles 'ASUSTeKcomputer.Inc\nhAsusStrix\UserInterface'
$script:Exe = Join-Path $script:DriverDir 'nhAsusStrixSvc32.exe'

function Get-Svc32Processes {
    $filter = "Name='nhAsusStrixSvc32.exe' AND SessionId=" + $script:Session
    Get-CimInstance Win32_Process -Filter $filter -OperationTimeoutSec 10
}

function Test-AudioReady {
    foreach ($name in @('Audiosrv', 'AudioEndpointBuilder')) {
        try {
            if ((Get-Service -Name $name).Status -ne 'Running') { return $false }
        } catch { return $false }
    }
    try {
        $devices = @(Get-PnpDevice -PresentOnly -Class @('MEDIA', 'AudioEndpoint') |
            Where-Object {
                $_.FriendlyName -match '(?i)STRIX' -or
                $_.InstanceId -like 'USB\VID_0B05&PID_180C*'
            })
        $endpoints = @($devices | Where-Object {
            $_.Class -eq 'AudioEndpoint' -and $_.Status -eq 'OK'
        })
        return ($endpoints.Count -gt 0)
    } catch { return $false }
}

function Wait-AudioRegistration {
    $timer = [Diagnostics.Stopwatch]::StartNew()
    $stableFrom = -1.0
    while ($timer.Elapsed.TotalSeconds -lt 120) {
        if (-not (Test-Path -LiteralPath $script:Enabled)) { return $false }
        if (Test-AudioReady) {
            if ($stableFrom -lt 0) { $stableFrom = $timer.Elapsed.TotalSeconds }
            if (($timer.Elapsed.TotalSeconds - $stableFrom) -ge 15) { return $true }
        } else {
            $stableFrom = -1.0
        }
        Start-Sleep -Seconds 5
    }
    # A detection timeout must not block the known working activation command.
    return (Test-Path -LiteralPath $script:Enabled)
}

function Invoke-Worker {
    $mutex = New-Object -TypeName System.Threading.Mutex -ArgumentList @(
        $false, ('Local\ASUS_StrixControlFix_' + $script:Sid)
    )
    $locked = $false
    try {
        try { $locked = $mutex.WaitOne(0) }
        catch [Threading.AbandonedMutexException] { $locked = $true }
        if (-not $locked -or -not (Test-Path -LiteralPath $script:Enabled)) { return 0 }
        if (-not (Test-Path -LiteralPath $script:Exe)) { return 2 }
        if (-not (Wait-AudioRegistration)) { return 0 }
        $timer = [Diagnostics.Stopwatch]::StartNew()
        $attempts = 0
        $nextAttempt = 0.0
        $stableFrom = -1.0
        $lastKeys = ''
        while ($timer.Elapsed.TotalSeconds -lt 120) {
            if (-not (Test-Path -LiteralPath $script:Enabled)) { return 0 }
            $canObserve = $true
            $hosts = @()
            try {
                $hosts = @(Get-Svc32Processes)
                $keys = (@($hosts | ForEach-Object { $_.ProcessId } | Sort-Object) -join ',')
                if ($keys -ne '') {
                    if ($keys -ne $lastKeys -or $stableFrom -lt 0) {
                        $stableFrom = $timer.Elapsed.TotalSeconds
                    }
                } else {
                    $stableFrom = -1.0
                }
                $lastKeys = $keys
            } catch {
                $canObserve = $false
                $stableFrom = -1.0
                $lastKeys = ''
            }
            $launch = ($attempts -eq 0) -or (
                $canObserve -and $hosts.Count -eq 0 -and
                $attempts -lt 3 -and $timer.Elapsed.TotalSeconds -ge $nextAttempt
            )
            if ($launch) {
                $attempts++
                Start-Process -FilePath $script:Exe -ArgumentList '/start StrixControl' `
                    -WorkingDirectory $script:DriverDir -WindowStyle Hidden
                $nextAttempt = $timer.Elapsed.TotalSeconds + 30
                $stableFrom = -1.0
                $lastKeys = ''
            }
            Start-Sleep -Seconds 5
        }
        try { $hosts = @(Get-Svc32Processes) } catch { return 3 }
        $keys = (@($hosts | ForEach-Object { $_.ProcessId } | Sort-Object) -join ',')
        if ($hosts.Count -eq 0) { return 2 }
        if ($keys -eq $lastKeys -and $stableFrom -ge 0) {
            $stableSeconds = $timer.Elapsed.TotalSeconds - $stableFrom
        } else {
            $stableSeconds = 0
        }
        if ($stableSeconds -lt 30) { return 3 }
        return 0
    } finally {
        if ($locked) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}

function Get-OurTask {
    Get-ScheduledTask -TaskName $script:TaskName -TaskPath '\' -ErrorAction SilentlyContinue
}

function Assert-OurTask($Task) {
    if ($null -eq $Task) { return }
    $markers = @('Managed by StrixControlFix.ps1 v1.0', 'Managed by StrixControlFix.ps1 v1.1',
        'Managed by StrixControlFix.ps1 v1.2', $script:Marker)
    $actions = @($Task.Actions)
    $matching = @($actions | Where-Object {
        $_.Execute -ieq $script:PowerShell -and
        $_.Arguments.IndexOf(('"' + $script:Installed + '"'),
            [StringComparison]::OrdinalIgnoreCase) -ge 0
    })
    if ($Task.Description -notin $markers -or $actions.Count -ne 1 -or $matching.Count -ne 1) {
        throw ('Задача с таким именем создана другой программой: ' + $script:TaskName)
    }
}

function Install-Fix {
    if (-not (Test-Path -LiteralPath $script:Exe)) {
        throw ('Сначала установи драйвер и Sonic Studio ASUS. Не найден файл: ' + $script:Exe)
    }
    Import-Module ScheduledTasks
    $task = Get-OurTask
    Assert-OurTask $task
    New-Item -ItemType Directory -Path $script:Base -Force | Out-Null
    if ([IO.Path]::GetFullPath($PSCommandPath) -ine $script:Installed) {
        Copy-Item -LiteralPath $PSCommandPath -Destination $script:Installed -Force
    }
    $arguments = '-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "' +
        $script:Installed + '" -Mode Worker'
    $action = New-ScheduledTaskAction -Execute $script:PowerShell `
        -Argument $arguments -WorkingDirectory $script:Base
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User $script:Sid
    $trigger.Delay = 'PT20S'
    $principal = New-ScheduledTaskPrincipal -UserId $script:Sid `
        -LogonType Interactive -RunLevel Limited
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable `
        -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
        -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero)
    Register-ScheduledTask -TaskName $script:TaskName -TaskPath '\' `
        -Action $action -Trigger $trigger -Principal $principal `
        -Settings $settings -Description $script:Marker -Force | Out-Null
    Set-Content -LiteralPath $script:Enabled -Value 'enabled' -Encoding ASCII
    Write-Host 'Облегчённый автозапуск 1.3 Clean установлен.'
    Write-Host 'После следующего входа в Windows он будет работать автоматически.'
    Write-Host 'Для проверки подожди около 3 минут после входа и проверь колесо.'
}

function Uninstall-Fix {
    Import-Module ScheduledTasks
    $task = Get-OurTask
    Assert-OurTask $task
    if (Test-Path -LiteralPath $script:Enabled) {
        Remove-Item -LiteralPath $script:Enabled
    }
    if ($null -ne $task) {
        Unregister-ScheduledTask -TaskName $script:TaskName -TaskPath '\' -Confirm:$false
    }
    Write-Host 'Автозапуск отключён, задача удалена.'
}

try {
    switch ($Mode) {
        'Install'   { Install-Fix }
        'Worker'    { exit (Invoke-Worker) }
        'Uninstall' { Uninstall-Fix }
    }
    exit 0
} catch {
    if ($Mode -ne 'Worker') { Write-Host ('Ошибка: ' + $_.Exception.Message) -ForegroundColor Red }
    exit 1
}
